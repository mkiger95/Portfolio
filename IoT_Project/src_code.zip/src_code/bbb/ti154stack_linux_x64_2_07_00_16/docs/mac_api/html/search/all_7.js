var searchData=
[
  ['gpduration',['gpDuration',['../struct__apimac__mcpsdatareq.html#a82108959181d0bb540d2d2b2c379bdac',1,'_apimac_mcpsdatareq']]],
  ['gpoffset',['gpOffset',['../struct__apimac__mcpsdatareq.html#aa0175bd4548b568f1f23cf68eec46592',1,'_apimac_mcpsdatareq']]],
  ['gtspermit',['gtsPermit',['../struct__apimac__pandesc.html#ab93eab4f3f0bdecf5924922e63341cdb',1,'_apimac_pandesc']]]
];
