These prebuilt images are to be used with the native and ble OAD feature.

hexfiles/oad/
├── bim_offchip_cc13x2lp.hex - Boot Image Manager hex file
├── erase_storage_offchip_cc13x2lp.hex - Utility application to erase external flash
├── sensor_oad_cc13x2lp_app_v1.bin - 15.4 sensor OAD bin with v1 in image header.
└── sensor_oad_cc13x2lp_app_v2.bin - 15.4 sensor OAD bin with v2 in image header.

For more information refer the sensor_oad_cc13x2lp project readme.txt and the OAD documentation.
