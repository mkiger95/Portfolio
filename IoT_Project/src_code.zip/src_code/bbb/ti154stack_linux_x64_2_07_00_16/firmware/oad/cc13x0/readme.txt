These prebuilt images are to be used with the native and ble OAD feature. These have been generated with CCS tool chain.

Below are the prebuilt images that are to be used for native 15.4 OAD:

hexfiles/oad/
├── bim_extflash_cc13x0lp_TIRTOS_IN_ROM.hex - Boot Image Manager hex file. Intended for native OAD of Image using 15.4 stack.
├── sensor_oad_cc13x0lp_all.hex - 15.4 OAD hex that contains contains bim. Intended for download with Uniflash.
├── sensor_oad_cc13x0lp_app.bin - 15.4 OAD bin. Intended for OAD.


Below are the prebuilt images that are to be used for Ble OAD of 15.4 Image:

hexfiles/oad/
├── bim_extflash_cc13x0lp_TIRTOS_IN_FLASH.hex -Boot Image Manager hex file. Intended for BLE OAD of Image using 15.4 stack.
├── sensor_oad_cc13x0lp_app.hex - 15.4 OAD hex (does not contain bim; Intended for OAD download with Device Monitor. Refer to recreating the OAD binary in "ROM’ed TIRTOS Optimizations" section in the README.html in the sensor_oad project for more details). The pre-built image is built with non beacon mode of operation.
├── host_test_cc13x0lp_all.hex - BLE Host test used as OAD server with BLE Device Monitor
├── simple_peripheral_cc13x0lp_all.hex - BLE Simple Peripheal containing Application, Stack and BIM. Intended for download with Uniflash.

Below are the prebuilt images of some utility applications:

hexfiles/oad/
├── erase_extflash_cc1350lp.hex - Utility application to erase external flash
├── empty_app.bin - Small OAD bin for debug and development (does not contain bim). The example will simply boot and toggle the LED's, no 15.4 functionality is included

For more information refer the OAD documentation.
