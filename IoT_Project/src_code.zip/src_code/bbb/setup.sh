apt-get update 
apt-get upgrade
apt-get install libcurl4-gnutls-dev libexpat1-dev gettext libz-dev libssl-dev -y
apt-get install git -y
apt-get install autoconf automake libtool -y
apt-get install libncurses-dev bison flex patch -y
apt-get install cvs texinfo build-essential -y
apt-get install gcc-arm-linux-gnueabi -y
apt-get clean
apt-get install build-essential python-dev python-setuptools python-pip python-smbus -y
pip install Adafruit_BBIO

